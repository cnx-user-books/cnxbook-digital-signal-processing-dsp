//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//

/*File InverseComplexToReal01.java
Copyright 2004, R.G.Baldwin
Rev 5/24/04

Although there are more efficient ways to write
this program, it was written the way it was to
mimic the behavior of an FFT algorithm.
Therefore, the complex input must extend from
zero to the sampling frequency.

The static method named inverseTransform performs
a complex to real inverse discrete Fourier
transform returning a real result only.  In other
words, the method transforms a complex input to a
real output.

Does not implement the FFT algorithm. Implements
a straight-forward sampled-data version of the
continuous inverse Fourier transform defined
using integral calculus.

The parameters are:
double[] realIn - incoming real data
double[] imagIn - incoming imag data
double[] realOut - outgoing real data

Considers the data length to be
 realIn.length
Computational time increment is
 1.0/realIn.length

Returns a number of points equal to the data
length.

Assumes real input consists of positive
frequency points for a symmetric real frequency
function.  That is, the real input is assumed to
be symmetric about the folding frequency.  Does
not test this assumption.

Assumes imaginary input consists of positive
frequency points for an asymmetric imaginary
frequency function.  That is, the imaginary input
is assumed to be asymmetric about  the
folding frequency.  Does not test this
assumption.

The assumption of a symmetric real part and an
asymmetric imaginary part guarantees that the
imaginary output would be all zero if it were to
be computed.  Thus the program makes no attempt
to compute an imaginary output.

Tested using J2SE v1.4.2 under WinXP.
************************************************/

public class InverseComplexToReal01{

  public static void inverseTransform(
                               double[] realIn,
                               double[] imagIn,
                               double[] realOut){
    int dataLen = realIn.length;
    double delT = 1.0/realIn.length;
    double startTime = 0.0;
    //Outer loop interates on time domain
    // values.
    for(int i=0; i < dataLen;i++){
      double time = startTime + i*delT;
      double real = 0;
      //Inner loop iterates on frequency
      // domain values.
      for(int j=0; j < dataLen; j++){
        real += realIn[j]*
                      Math.cos(2*Math.PI*time*j)
             + imagIn[j]*
                      Math.sin(2*Math.PI*time*j);
      }//end inner loop
      realOut[i] = real;
    }//end outer loop
  }//end inverseTransform

}//end class InverseComplexToReal01