//345678901234567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=======================================================//

//Be sure to preserve < and > in html version
//Ready for publication.

/*File ImgMod35a.java
Copyright 2005, R.G.Baldwin

This is a modification of ImgMod35 to normalize and display
wave-number spectra instead of constructing a replica of
the original image.  In addition, whereas ImgMod35 uses a
fixed block size of 8x8 pixels, this program allows the 
user to specify the block size.

This program performs a forward DCT on an image converting 
the three color planes into spectral planes.  The three
spectral planes are normalized so as to make them suitable
for being displayed as standard image data.  The 
normalization includes transformation of the spectral data
to log base 10 and scaling to cause the values to fall 
between 0 and 255 inclusive.

This program breaks the image down into square blocks of 
pixels and performs a forward DCT on each block producing 
and displaying square blocks of spectral data.  The size of
the blocks is specified by the user by entering the size 
into a text field and pressing the Replot button.

Each color plane is individually processed.

Note that for small block sizes, this version of the 
program is significantly faster than the version named 
ImgMod034a, which does not break the image down into 
blocks, but rather does the forward DCT on the entire 
image.

This program can handle any block size up to the size of 
the original image.  However, it is optimized for block 
sizes of 8x8 pixels.  When the block size is 8x8 pixels, 
the program uses an 8x8 cosine lookup table instead of 
computing the cosine value every time it is needed.  This 
should cause the program to run faster.

The class is designed to be driven by the class named 
ImgMod02a.  

Enter the following at the command line to run this 
program:

java ImgMod02a ImgMod35a ImageFileName

where ImageFileName is the name of a .gif or .jpg file, 
including the extension.

When the user clicks the Replot button, the process is 
repeated using the potentially new value for bloxk size
and the new results are displayed.

This program requires access to the following class files 
plus some inner classes that are defined inside the
following classes:

ImgIntfc02.class
ImgMod02a.class
ImgMod35a.class
ForwardDCT02.class

Tested using J2SE 5.0 and WinXP.  J2SE 5.0 or later is 
required due to the use of static imports.
**********************************************************/
import java.awt.*;
import java.io.*;
import static java.lang.Math.*;

class ImgMod35a extends Frame implements ImgIntfc02{
  
  //The user can enter a value into the following field and
  // then click the Replot button.  The image will be
  // broken down into square blocks of pixels where the
  // number of pixels on each side matches the value
  // entered by the user.  Then the image will be 
  // processed one block at a time.
  TextField subSizeField = new TextField("8");
  Label instructions = new Label(
                  "Enter sub-image size and click Replot");
  //-----------------------------------------------------//
  ImgMod35a(){//constructor
    add(instructions,BorderLayout.CENTER);
    add(subSizeField,BorderLayout.SOUTH);
    setTitle("Copyright 2006, R.G.Baldwin");
    setBounds(400,0,250,75);
    setVisible(true);
  }//end constructor
  //-----------------------------------------------------//
                                        
  //This method is required by ImgIntfc02.  It is called at
  // the beginning of the run and each time thereafter that
  // the user clicks the Replot button on the Frame
  // contaning the images.
  public int[][][] processImg(int[][][] threeDPix,
                              int imgRows,
                              int imgCols){

    //The image is broken down into square blocks where the
    // following value specifies the dimensions of the
    // blocks.
    int imgSubSize = Integer.parseInt(
                                   subSizeField.getText());

    //Create an empty output array of the same size as the
    // incoming array.
    int[][][] output = new int[imgRows][imgCols][4];

    //Make a working copy of the 3D pixel array as type
    // double to avoid making permanent changes to the
    // original image data.  Also, all processing will be
    // performed as type double.
    double[][][] working3D = copyToDouble(threeDPix);
    
    //The following code can be enabled to set any of the
    // three colors to black, thus removing them from the
    // output.
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
//        working3D[row][col][1] = 0;//Red
//        working3D[row][col][2] = 0;//Green
//        working3D[row][col][3] = 0;//Blue
      }//end inner loop
    }//end outer loop
    
    //Extract and do a forward DCT on the red color plane,
    // one block at a time.
    double[][] redPlane = extractPlane(working3D,1);
    //Expand the plane such that both dimensions are a
    // multiple of imgSubSize.
    redPlane = expandPlane(redPlane,imgSubSize);
    //Do the forward DCT on the redPlane turning it into a
    // spectral plane where each individual spectrum
    // stored in the plane is a square block with
    // dimensions of imgSubSize.
    //To see the individual spectra, disable all but one
    // color plane above.
    forwardXformPlane(redPlane,imgSubSize);

    //Normalize the data in a 2D double plane to make it
    // compatible with being displayed as an image plane.
    // See the comments in the normalize method for an
    // explanation as to how the normalization is
    // accomplished.
    normalize(redPlane);
    
    //Insert the spectral plane back into the 3D array. 
    // This method also trims off any extra rows and
    // columns created by expanding the dimensions to a
    // multiple of imgSubSize.
    insertPlane(working3D,redPlane,1);

    //Extract and do a forward DCT on the green color
    // plane using the same procedure used for the red
    // plane above.
    double[][] greenPlane = extractPlane(working3D,2);
    greenPlane = expandPlane(greenPlane,imgSubSize);
    forwardXformPlane(greenPlane,imgSubSize);
    normalize(greenPlane);
    insertPlane(working3D,greenPlane,2);

    //Extract and do a forward DCT on the blue color plane
    //  using the same procedure used for the red plane
    // above..
    double[][] bluePlane = extractPlane(working3D,3);
    bluePlane = expandPlane(bluePlane,imgSubSize);
    forwardXformPlane(bluePlane,imgSubSize);
    normalize(bluePlane);
    insertPlane(working3D,bluePlane,3);
    
    //All three color planes have now been transformed into
    // spectral planes where each spectral plane is
    // composed of a potentially large number of contiguous
    // square spectral data blocks of size imgSubSize.
    
    //Convert the image color planes to type int and return
    // the array of pixel data to the calling method.
    output = copyToInt(working3D);
    //Return a reference to the output array.
    return output;

  }//end processImg method
  //-----------------------------------------------------//

  //The purpose of this method is to extract a specified
  // row from a double 2D plane and to return it as a one-
  // dimensional array of type double.
  double[] extractRow(double[][] colorPlane,int row){
    
    int numCols = colorPlane[0].length;
    double[] output = new double[numCols];
    for(int col = 0;col < numCols;col++){
      output[col] = colorPlane[row][col];
    }//end outer loop
    return output;
  }//end extractRow
  //-----------------------------------------------------//

  //The purpose of this method is to insert a specified
  // row of double data into a double 2D plane.
  void insertRow(double[][] colorPlane,
                 double[] theRow,
                 int row){
    int numCols = colorPlane[0].length;
    double[] output = new double[numCols];
    for(int col = 0;col < numCols;col++){
      colorPlane[row][col] = theRow[col];
    }//end outer loop
  }//end insertRow
  //-----------------------------------------------------//

  //The purpose of this method is to extract a specified
  // col from a double 2D plane and to return it as a one-
  // dimensional array of type double.
  double[] extractCol(double[][] colorPlane,int col){
    int numRows = colorPlane.length;
    double[] output = new double[numRows];
    for(int row = 0;row < numRows;row++){
      output[row] = colorPlane[row][col];
    }//end outer loop
    return output;
  }//end extractCol
  //-----------------------------------------------------//

  //The purpose of this method is to insert a specified
  // col of double data into a double 2D color plane.
  void insertCol(double[][] colorPlane,
                 double[] theCol,
                 int col){
    int numRows = colorPlane.length;
    double[] output = new double[numRows];
    for(int row = 0;row < numRows;row++){
      colorPlane[row][col] = theCol[row];
    }//end outer loop
  }//end insertCol
  //-----------------------------------------------------//
  
  //The purpose of this method is to extract a color plane
  // from the double version of an image and to return it
  // as a 2D array of type double.
  public double[][] extractPlane(
                              double[][][] threeDPixDouble,
                              int plane){
    
    int numImgRows = threeDPixDouble.length;
    int numImgCols = threeDPixDouble[0].length;
    
    //Create an empty output array of the same
    // size as a single plane in the incoming array of
    // pixels.
    double[][] output =new double[numImgRows][numImgCols];

    //Copy the values from the specified plane to the
    // double array.
    for(int row = 0;row < numImgRows;row++){
      for(int col = 0;col < numImgCols;col++){
        output[row][col] =
                          threeDPixDouble[row][col][plane];
      }//end loop on col
    }//end loop on row
    return output;
  }//end extractPlane
  //-----------------------------------------------------//
  
  //The purpose of this method is to insert a double 2D
  // plane into the double 3D array that represents an
  // image.  This method also trims off any extra rows and
  // columns in the double 2D plane.
  public void insertPlane(double[][][] threeDPixDouble,
                          double[][] colorPlane,
                          int plane){
    
    int numImgRows = threeDPixDouble.length;
    int numImgCols = threeDPixDouble[0].length;
    
    //Copy the values from the incoming color plane to the
    // specified plane in the 3D array.
    for(int row = 0;row < numImgRows;row++){
      for(int col = 0;col < numImgCols;col++){
        threeDPixDouble[row][col][plane] = 
                                      colorPlane[row][col];
      }//end loop on col
    }//end loop on row
  }//end insertPlane
  //-----------------------------------------------------//

  //This method copies an int version of a 3D pixel array
  // to an new pixel array of type double.
  double[][][] copyToDouble(int[][][] threeDPix){
    int imgRows = threeDPix.length;
    int imgCols = threeDPix[0].length;
    
    double[][][] new3D = new double[imgRows][imgCols][4];
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        new3D[row][col][0] = threeDPix[row][col][0];
        new3D[row][col][1] = threeDPix[row][col][1];
        new3D[row][col][2] = threeDPix[row][col][2];
        new3D[row][col][3] = threeDPix[row][col][3];
      }//end inner loop
    }//end outer loop
    return new3D;
  }//end copyToDouble
  //-----------------------------------------------------//
  
  //This method copies a double version of a 3D pixel array
  // into a new pixel array of type int.
  int[][][] copyToInt(double[][][] threeDPixDouble){
    int imgRows = threeDPixDouble.length;
    int imgCols = threeDPixDouble[0].length;
    
    int[][][] new3D = new int[imgRows][imgCols][4];
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        new3D[row][col][0] = 
                         (int)threeDPixDouble[row][col][0];
        new3D[row][col][1] = 
                         (int)threeDPixDouble[row][col][1];
        new3D[row][col][2] = 
                         (int)threeDPixDouble[row][col][2];
        new3D[row][col][3] = 
                         (int)threeDPixDouble[row][col][3];
      }//end inner loop
    }//end outer loop
    return new3D;
  }//end copyToInt
  //-----------------------------------------------------//

  //Expand a double 2D plane such that both dimensions are
  // a multiple of imgSubSize.
  double[][] expandPlane(double[][] plane,int imgSubSize){
    int rows = plane.length;
    int cols = plane[0].length;
    double[][] output;
    
    int rowsRem = rows%imgSubSize;
    int colsRem = cols%imgSubSize;
    
    if((rowsRem == 0) && (colsRem == 0)){
      //No expansion is required.
      return plane;
    }else{
      //An expansion is required.  Copy the data from the
      // incoming array to a new expanded array, leaving
      // pad values of 0.0 at the right and bottom edges.
      output = new double[rows + (imgSubSize - rowsRem)]
                         [cols + (imgSubSize - colsRem)];
      for(int row = 0;row < rows;row++){
        for(int col = 0;col < cols;col++){
          output[row][col] = plane[row][col];
        }//end inner loop
      }//end outer loop
      return output;
    }//end else
  }//end expandPlane
  //-----------------------------------------------------//
  
  //Extracts and returns a square block of size imgSubSize
  // from a double 2D plane
  double[][] getSubPlane(double[][] colorPlane,
                         int segRow,
                         int segCol,
                         int imgSubSize){
    double[][] theSubPlane = 
                        new double[imgSubSize][imgSubSize];
    for(int bigRow = segRow * imgSubSize,smallRow = 0;
               bigRow < (segRow * imgSubSize + imgSubSize);
                                      bigRow++,smallRow++){
      for(int bigCol = segCol * imgSubSize,smallCol = 0;
                 bigCol < segCol * imgSubSize + imgSubSize;
                                      bigCol++,smallCol++){
        theSubPlane[smallRow][smallCol] = 
                                colorPlane[bigRow][bigCol];
      }//end inner loop
    }//end outer loop
    return theSubPlane;
  }//end getSubPlane
  //-----------------------------------------------------//

  //Inserts square block of size imgSubSize into a double
  // 2D plane
  void insertSubPlane(double[][] colorPlane,
                      double[][] theSubPlane,
                      int segRow,
                      int segCol,
                      int imgSubSize){
    for(int bigRow = segRow * imgSubSize,smallRow = 0;
               bigRow < (segRow * imgSubSize + imgSubSize);
                                      bigRow++,smallRow++){
      for(int bigCol = segCol * imgSubSize,smallCol = 0;
                 bigCol < segCol * imgSubSize + imgSubSize;
                                      bigCol++,smallCol++){
        colorPlane[bigRow][bigCol] = 
                           theSubPlane[smallRow][smallCol];
      }//end inner loop
    }//end outer loop
  }//end insertSubPlane
  //-----------------------------------------------------//
  
  //Breaks a double color plane down into square blocks
  // of size imgSubSize and does a forward DCT xform on
  // each block.
  //Assembles the resulting spectral data blocks into a
  // spectral plane.
  //Assumes that the dimensions of the color plane are
  // multiples of imgSubSize.
  void forwardXformPlane(double[][] plane,int imgSubSize){
    int pixRows = plane.length;
    int pixCols = plane[0].length;
    //Loop on rows of blocks
    for(int segRow = 0;segRow < pixRows/imgSubSize;
                                                 segRow++){
      //Loop on cols of blocks
      for(int segCol = 0;segCol < pixCols/imgSubSize;
                                                 segCol++){
        double[][] theSubPlane = 
               getSubPlane(plane,segRow,segCol,imgSubSize);
        forwardXformSubPlane(theSubPlane,imgSubSize);
        
        insertSubPlane(plane,
                       theSubPlane,
                       segRow,
                       segCol,
                       imgSubSize);
      }//end inner loop
    }//end outer loop
  }//end forwardXformPlane
  //-----------------------------------------------------//
  
  //This method does a forward DCT on a square block of
  // pixels of size imgSubSize received as an incoming
  // parameter.
  void forwardXformSubPlane(double[][] theSubPlane,
                            int imgSubSize){
    
    int imgRows = imgSubSize;
    int imgCols = imgSubSize;
    
    //Extract each row from the block and perform
    // a forward DCT on the row. Then insert the
    // transformed row back into the block.  At that point,
    // the row no longer contains color pixel data, but
    // has been transformed into a row of spectral data.
    for(int row = 0;row < imgRows;row++){
      double[] theRow = extractRow(theSubPlane,row);
      
      double[] theXform = new double[theRow.length];
      //Perform the forward transform.
      ForwardDCT02.transform(theRow,theXform);
      
      //Insert the transformed row back into the block.
      insertRow(theSubPlane,theXform,row);
    }//end for loop
    
    //The block now contains the results of doing the
    // horizontal DCT one row at a time.  The block no
    // longer contains color pixel data.  Rather, it
    // contains spectral data for the horizontal dimension
    // only.
    
    //Extract each column from the block and perform a
    // forward DCT on the column. Then insert the
    // transformed column back into the block.
    for(int col = 0;col < imgCols;col++){
      double[] theCol = extractCol(theSubPlane,col);

      double[] theXform = new double[theCol.length];
      ForwardDCT02.transform(theCol,theXform);

      insertCol(theSubPlane,theXform,col);
    }//end for loop
    
    //The square block of size imgSubSize has now been
    // converted into a square block of spectral
    // coefficient data of the same size.

  }//end forwardXformSubPlane
  //-----------------------------------------------------//

  //Normalizes the data in a 2D double plane to make it
  // compatible with being displayed as an image plane.
  //First all negative values are converted to positive
  // values.
  //Then all values are converted to log base 10 to
  // preserve the dynamic range of the plotting system. 
  // All negative values are set to 0 at this point.
  //Then all values that are below X-percent of the maximum
  // value are set to X-percent of the maximum value
  // producing a floor for the values.
  //Then all values are biased so that the minimum value
  // (the floor) becomes 0.
  //Then all values are scaled so that the maximum value
  // becomes 255.
  void normalize(double[][] plane){
    int rows = plane.length;
    int cols = plane[0].length;
    
    //Begin by converting all negative values to positive
    // values.  This is equivalent to the computation of
    // the magnitude for purely real data.
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        if(plane[row][col] < 0){
          plane[row][col] = - plane[row][col];
        }//end if
      }//end inner loop
    }//end outer loop
    
    //Convert the values to log base 10 to preserve the
    // dynamic range of the plotting system.  Set negative
    // values to 0.

    //First eliminate or change any values that are
    // incompatible with log10 method.
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        if(plane[row][col] == 0.0){
          plane[row][col] = 0.0000001;
        }else if(plane[row][col] == Double.NaN){
          plane[row][col] = 0.0000001;
        }else if(plane[row][col] == 
                                 Double.POSITIVE_INFINITY){
          plane[row][col] = 9999999999.0;
        }//end else
      }//end inner loop
    }//end outer loop

    //Now convert the data to log base 10 setting all
    // negative results to 0.
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        plane[row][col] = log10(plane[row][col]);
        if(plane[row][col] < 0){
          plane[row][col] = 0;
        }//end if
      }//end inner loop
    }//end outer loop

    //Now set everything below X-percent of the maximum
    // value to X-percent of the maximum value where X is
    // determined by the value of scale.
    double scale = 1.0/7.0;
    //First find the maximum value.
    double max = Double.MIN_VALUE;
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        if(plane[row][col] > max){
          max = plane[row][col];
        }//end if
      }//end inner loop
    }//end outer loop

    //Now set everything below X-percent of the maximum to
    // X-percent of the maximum value and and slide
    // everything down to cause the new minimum to be
    // at 0.0
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        if(plane[row][col] < scale * max){
          plane[row][col] = scale * max;
        }//end if
        plane[row][col] -= scale * max;
      }//end inner loop
    }//end outer loop
    
    //Now scale the data so that the maximum value is 255.

    //First find the maximum value
    max = Double.MIN_VALUE;
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        if(plane[row][col] > max){
          max = plane[row][col];
        }//end if
      }//end inner loop
    }//end outer loop
    //Now scale the data.
    for(int row = 0;row < rows;row++){
      for(int col = 0;col < cols;col++){
        plane[row][col] = plane[row][col] * 255.0/max;
      }//end inner loop
    }//end outer loop

  }//end normalize
  //-----------------------------------------------------//
}//end class ImgMod35a